/* L.tilelayer is used to load and display tile layers on the map
 * these tiles are fetched from maps.stamen.com

Add other tiles easely from this link :)
    - Select a map and copy the code
    - Remember to add .addTo(map); the same way as on the example above
    - Delete or outcomment the example above (some tiles can be added on top of others)
    - For some of the tilesets you will need a token like with Mapbox

http://leaflet-extras.github.io/leaflet-providers/preview/index.html 
*/

// STEP 1) STARTS HERE initilising the maå
/* var map = L.map('map').fitWorld(); 

//what kind of tile
L.tileLayer( "https://stamen-tiles.a.ssl.fastly.net/terrain/{z}/{x}/{y}.jpg", {
    attribution: "",
    maxZoom: 16,
}).addTo(map); */

//Det andet map, der var lidt mere a la maps:
var map = L.map('map').setView([55.41, 12.57], 13);

const accesToken = "pk.eyJ1Ijoic29mZmxvZiIsImEiOiJjbDB0a2VtdnEwN2d0M2lrYndpY2NnbTgyIn0.xjuLeS20jSO_RQM8VN0Mfw"

L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox/streets-v11',
    tileSize: 512,
    zoomOffset: -1,
    accessToken: accesToken
}).addTo(map);

// Setview with geolocation - where the view should be framed
map.locate({setView: true, maxZoom: 10});

/**
* The onLocationFound function adds a marker in the detected location,
showing accuracy in a popup, * by adding an event listener to
locationfound event before the locateAndSetView call
*/
function onLocationFound(e) {
    var radius = e.accuracy;
    
   /*  L.marker(e.latlng, { icon: positionIcon })
        .addTo(map)
        .bindPopup("You are within " + radius + " meters from this point")
        .openPopup();
 */
    L.circle(e.latlng, radius)
        .addTo(map); }

    // event listener for the event 'locationfound'
    map.on('locationfound', onLocationFound);

    /**
    * The onLocationError function sends an alert if the geolocation failed. */

    function onLocationError(e) { alert(e.message);
    }

    map.on('locationerror', onLocationError);

let iconObject = L.Icon.extend({
    options: {
    iconSize: [50, 50], // size of the icon
    popupAnchor: [-3, -76], // point from which the popup should open relative to the iconAnchor
    },
});

// custom icons
let visitIcon = new iconObject({ iconUrl: "./icons/report.png" });
let positionIcon = new iconObject({ iconUrl: "./icons/location.png" });

/**
* the onMapClick function adds a marker to the visitedArray with the push function,
* every time the users clicks on the map. The array of visited places is added as markers to the map. */
let visitedArray = [];
function onMapClick(e) {
    visitedArray.push(
    L.marker(e.latlng, {
        draggable: true,
        autoPan: true,
        icon: visitIcon,
    })
    .addTo(map)
    //.bindPopup("You have visited this place!")
);
// console logs the array of places the user has marked as visited
console.log(visitedArray); }
// run the onMapClick function when the map is clicked
map.on("click", onMapClick);

//heatmat stuff:
var heat = L.heatLayer([
	[55.65, 12.5, 0.2], // lat, lng, intensity
    [55.8, 12.4, 0.2],
    [55.85, 12.4, 0.2],
    [55.856, 12.4, 0.2],
    [55.87, 12.4, 0.2],
    [55.88, 12.4, 0.2],
    [55.89, 12.4, 0.2],
    [55.87, 12.5, 0.2],
    [55.87, 11.6, 0.2],
    [55.87, 11.6, 0.2],
    [55.87, 11.59, 0.2],
    [55.4, 12.3, 0.2],
    [55.72, 12.2, 0.2],
    [55.1, 12.1, 0.2],
    [55.33, 11.999, 0.2],
    [55.19, 11.89, 0.2],
    [55.6666, 12.37, 0.2],
    [55.6666, 12.37, 0.2],
    [55.7, 12.24, 0.2],
    [55.6666, 12.37, 0.2],
    [55.69, 12.55, 0.2],
    [55.689, 12.56, 0.2],
    [55.665, 12.6, 0.2],
    [55.648, 12.577, 0.2],
    [55.609, 12.6, 0.2],
    [55.609, 12.6, 0.2],
    [55.609, 12.6, 0.2],
    [55.61, 12.5, 0.2],
    [55.53, 11.64, 0.2],
    [55.51, 11.76, 0.2],
    [55.4, 11.52, 0.2],
    [55.55, 11.4, 0.2],
    [55.609, 12.6, 0.2],
    [55.98, 12.27, 0.2],
    [55.89, 12.19, 0.2],
    [55.641, 12.63, 0.2],
    [54.99, 11.93, 0.2]

    ],
    {radius : 25,
    minOpacity : 0.4, 
    gradient : {0.4: '#6AEC87', 0.5: 'yellow', 0.6: 'red'}}).addTo(map);

    
    